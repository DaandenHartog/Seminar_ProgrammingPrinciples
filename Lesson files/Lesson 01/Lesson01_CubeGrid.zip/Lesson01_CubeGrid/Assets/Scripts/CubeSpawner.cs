﻿using UnityEngine;
using System.Collections;

public class CubeSpawner : MonoBehaviour {
	
	public Texture2D Dirt, Grass;
	public Vector2 Size;

	private GameObject CubePrefab;

	void Start () {
		CubePrefab = (GameObject)Resources.Load ("Prefabs/Cube");

		//StartCoroutine (GenerateCubes ());	
		GenerateCubes ();
	}

	private void GenerateCubes(){
		for(int i = 0; i < Size.x; i++){
			for(int j = 0; j < Size.y; j++){
				SpawnCube(i, j);
				//yield return new WaitForSeconds(.05f);
			}
		}
	}

	private void SpawnCube(int row, int column){
		GameObject c = Instantiate (CubePrefab, new Vector3 (column, 0, row), Quaternion.identity) as GameObject;
		c.GetComponent<Renderer> ().material.mainTexture = (UnityEngine.Random.Range (0, 11) > 8) ?  Grass: Dirt;
	}

}

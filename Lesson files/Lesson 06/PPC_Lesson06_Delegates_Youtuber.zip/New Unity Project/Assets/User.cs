﻿using UnityEngine;
using System;
using System.Collections;

public class User : MonoBehaviour {

	private void Start(){
		StartCoroutine (LovePewdiepie ());
	}

	private void WatchVideo(){
		Debug.Log (gameObject.name + ": OMG IK ZO BLIJ DAT mdfsfds OMGOMGOMG");
	}

	private IEnumerator LovePewdiepie(){
		Youtuber pewdiepie = FindObjectOfType<Youtuber> ();
		pewdiepie.OnNewVideoDone += WatchVideo;

		int hateTimer = UnityEngine.Random.Range (15, 21);
		yield return new WaitForSeconds (hateTimer);

		Debug.Log(gameObject.name  + ": Wow, ik ben echt zo volwassen nu, hoe kon ik dit leuk vidnen");
		pewdiepie.OnNewVideoDone -= WatchVideo;
	}
}

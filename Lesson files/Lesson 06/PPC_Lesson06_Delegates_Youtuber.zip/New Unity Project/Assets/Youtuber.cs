﻿using UnityEngine;
using System;
using System.Collections;

public class Youtuber : MonoBehaviour {

	public Action OnNewVideoDone;

	private void Start(){
		StartCoroutine (MakeVideo());
	}

	private IEnumerator MakeVideo(){
		Debug.Log("I started making a new video.");

		yield return new WaitForSeconds (5);

		Debug.Log("New video is done!");
		if (OnNewVideoDone != null) {
			OnNewVideoDone ();
		}
		StartCoroutine (MakeVideo ());
	}
}

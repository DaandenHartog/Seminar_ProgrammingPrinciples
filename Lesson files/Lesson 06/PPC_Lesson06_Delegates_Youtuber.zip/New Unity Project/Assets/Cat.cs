﻿using UnityEngine;
using System;
using System.Collections;

public class Cat : MonoBehaviour {

	public Action<GameObject> OnWantSave;

	private void Start(){
		FireDepartment fd = FindObjectOfType<FireDepartment> ();

		OnWantSave += fd.SaveObject;

		StartCoroutine (Walk ());
	}

	private IEnumerator Walk(){

		int rand = 0;
		while(rand < 8){
			Debug.Log(gameObject.name +": I'm still walking.");
			yield return new WaitForSeconds(1);
			rand = UnityEngine.Random.Range (0, 11);
		}

		Debug.Log("Oh no! " + gameObject.name + " is stuck in a Tree!");
		yield return new WaitForSeconds(1);

		OnWantSave(gameObject);
	}
}

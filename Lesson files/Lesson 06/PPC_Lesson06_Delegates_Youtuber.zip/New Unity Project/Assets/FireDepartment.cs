﻿using UnityEngine;
using System.Collections;

public class FireDepartment : MonoBehaviour {

	public void SaveObject(GameObject go){
		Debug.Log(go.name + " has been saved.");
	}
}

﻿using UnityEngine;
using System.Collections;

public class Enemy : Entity {

	private Vector2[] directions = new Vector2[]{ Vector2.left, Vector2.up, Vector2.right, Vector2.down };

	private GameObject player;

	private void Start () {
		player = GameObject.FindObjectOfType<Player> ().gameObject;
		StartCoroutine (Move ());
	}

	private void Update()
	{
		CheckForPlayer ();
	}

	private void CheckForPlayer()
	{
		if (Map.IsAdjacent (transform.position, player.transform.position))
			Debug.Log ("CAught you");
	}

	private IEnumerator Move()
	{
		yield return new WaitForSeconds (UnityEngine.Random.Range (0.1f, 3f));

		CheckInput (directions [UnityEngine.Random.Range (0, directions.Length)]);

		StartCoroutine (Move ());
	}
}

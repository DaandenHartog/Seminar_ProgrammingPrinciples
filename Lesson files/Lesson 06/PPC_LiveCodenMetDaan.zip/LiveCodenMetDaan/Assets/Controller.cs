﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour {

	public GameObject tilePrefab;

	private void Start () {
		Map.InstantiateWorld (tilePrefab, 10, 10);
	}

	private void Update () {
	
	}
}

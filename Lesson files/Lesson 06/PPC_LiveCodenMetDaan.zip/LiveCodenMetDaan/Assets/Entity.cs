﻿using UnityEngine;
using System.Collections;

public class Entity : MonoBehaviour {

	private void Start()
	{
		Map.isOccupied [(int)transform.position.x, (int)transform.position.y] = true;
	}

	protected void CheckInput(Vector2 input)
	{
		Vector2 nextPosition = (Vector2)transform.position + input;
		
		if (nextPosition.x < 0 || nextPosition.y < 0 || nextPosition.x >= Map.isOccupied.GetLength(0) || nextPosition.y >= Map.isOccupied.GetLength(1) || Map.isOccupied[(int)nextPosition.x, (int)nextPosition.y])
			return;
		
		ApplyInput (nextPosition);
	}
	
	private void ApplyInput(Vector2 nextPosition)
	{
		Map.isOccupied [(int)transform.position.x, (int)transform.position.y] = false;
		Map.isOccupied [(int)nextPosition.x, (int)nextPosition.y] = true;
		
		transform.position = nextPosition;
	}

}

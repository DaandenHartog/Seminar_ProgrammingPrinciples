﻿using UnityEngine;
using System.Collections;

public class Player : Entity {

	private void Start () {
	
	}

	private void Update () {
		DetectInput ();
	}

	private void DetectInput()
	{
		Vector2 input = Vector2.zero;

		if (Input.GetKeyDown (KeyCode.A))
			input = Vector2.left;
		else
			if (Input.GetKeyDown (KeyCode.D))
				input = Vector2.right;
			else
				if (Input.GetKeyDown (KeyCode.W))
					input = Vector2.up;
				else
					if (Input.GetKeyDown (KeyCode.S))
						input = Vector2.down;

		if (input != Vector2.zero)
			CheckInput (input);
	}


}

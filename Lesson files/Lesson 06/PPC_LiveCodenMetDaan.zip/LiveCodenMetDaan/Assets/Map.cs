﻿using UnityEngine;
using System.Collections;

public static class Map {

	public static bool[,] isOccupied;
	private static Vector2[] directions = new Vector2[]{ Vector2.left, Vector2.up, Vector2.right, Vector2.down };

	public static void InstantiateWorld(GameObject tile, int width, int height)
	{
		GameObject parent = new GameObject ("tileParent");

		for (int x = 0; x < width; x++)
			for (int y = 0; y < height; y++) {
				GameObject newTile = GameObject.Instantiate(tile, new Vector2(x, y), Quaternion.identity) as GameObject;
				newTile.name = tile.name; 
				newTile.transform.parent = parent.transform;
			}

		// Set values
		isOccupied = new bool[width, height];
	}

	public static bool IsAdjacent(Vector2 a, Vector2 b)
	{
		foreach (Vector2 vector in directions)
			if (a + vector == b)
				return true;

		return false;
	}

}

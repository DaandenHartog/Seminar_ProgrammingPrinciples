﻿using System;
using UnityEngine;

public class FireDepartment : MonoBehaviour {

    public void SomeoneWantsSave(GameObject who) {
        Debug.Log(who.name + " has been saved by the Fire Department.");
    }

}

﻿using UnityEngine;
using System.Collections;
using System;

public class Cat : MonoBehaviour {

    //Een event triggeren met als parameter een Gameobject dat gered moet worden
    public Action<GameObject> OnWantsSave;

    private void Start() {
        //Eerst ons firedepartment zoeken.
        FireDepartment fireDepartment = FindObjectOfType<FireDepartment>();

        //Wanneer dit object gered wilt worden, zorgen dat ons fireDepartment dit weet
        //Unsubscribe is OnWantsSave -= fireDepartment.SomeoneWantsSave;
        OnWantsSave += fireDepartment.SomeoneWantsSave;

        //Dan de loop starten
        StartCoroutine(Walk());
    }

    private IEnumerator Walk() {
        int randomAction = 0;
        while (randomAction < 8) {
            Debug.Log(gameObject.name + " is just chilling.");
            yield return new WaitForSeconds(.5f);
            randomAction = UnityEngine.Random.Range(0, 11);
        }

        Debug.Log("Oh no! " + gameObject.name + " is stuck!");
        yield return new WaitForSeconds(1f);
        if (OnWantsSave != null) {
            OnWantsSave(gameObject);
        }
    }
}

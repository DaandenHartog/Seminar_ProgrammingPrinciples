﻿using UnityEngine;
using System.Collections;

public class Orc : MonoBehaviour {

	void Start () {
		Debug.Log("Hallo ik ben een orc");
	}
}

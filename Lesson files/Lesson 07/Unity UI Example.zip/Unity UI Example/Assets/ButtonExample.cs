﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ButtonExample : MonoBehaviour {

	private Button button;

	private void Start () {
		button = GetComponent<Button> ();
		button.onClick.AddListener (OnButtonClicked);
	}

	private void OnButtonClicked(){
		Debug.Log ("Ik ben geclicked.");
	}

}

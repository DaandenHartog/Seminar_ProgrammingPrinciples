﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class DragExample : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
	
	RectTransform rt;
	Canvas canvas;

	private void Start(){
		rt = GetComponent<RectTransform> ();
		canvas = FindObjectOfType<Canvas> ();
	}


	public void OnBeginDrag (PointerEventData eventData)
	{
		rt.SetParent (canvas.transform);
	}

	public void OnDrag (PointerEventData eventData)
	{
		rt.position = eventData.position;
	}

	public void OnEndDrag (PointerEventData eventData)
	{
		Debug.Log (eventData.pointerCurrentRaycast);
	}

}

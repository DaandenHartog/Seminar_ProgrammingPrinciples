﻿using UnityEngine;
using System.Collections;

public class Temp : MonoBehaviour {

	void Update () {
		if (Input.GetKeyDown (KeyCode.Q))
			AudioManager.instance.PlayAudio ("sound1", 1f, 1.5f, true);
		if (Input.GetKeyDown (KeyCode.W))
			AudioManager.instance.PlayAudio ("sound2");
		if (Input.GetKeyDown (KeyCode.E))
			AudioManager.instance.PlayAudio ("sound3");
		if (Input.GetKeyDown (KeyCode.R))
			AudioManager.instance.PlayAudio ("sound4");

		if (Input.GetKeyDown (KeyCode.A))
			AudioManager.instance.StopAudio ("sound1");
	}
}

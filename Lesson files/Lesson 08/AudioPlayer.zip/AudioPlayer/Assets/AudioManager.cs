﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AudioManager : MonoBehaviour {

	private static AudioManager _instance;
	public static AudioManager instance { get { return _instance ?? (_instance = new GameObject("AudioManager").AddComponent<AudioManager>()); } }

	private void Awake()
	{
		_instance = this;
		DontDestroyOnLoad (gameObject);
	}

	// AudioSource list which contains all audioSources
	private List<AudioSource> audioSources = new List<AudioSource>();

	public void PlayAudio(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
	{
		// Use a local Audiosource
		AudioSource audioSource = GetAudioSource ();

		// Set the correct values of the audiosource
		audioSource.clip = clip;
		audioSource.volume = volume;
		audioSource.pitch = pitch;
		audioSource.loop = loop;

		// Actually play the audio
		audioSource.Play ();
	}

	public void PlayAudio(string clipName, float volume = 1f, float pitch = 1f, bool loop = false)
	{
		// Load a audioClip, based on the name we received
		AudioClip clip = Resources.Load ("Audio/" + clipName) as AudioClip;

		// If the clip failed to load, we throw a warning
		if (clip == null) {
			Debug.LogWarning("The audioclip " + clipName + " could not be found");
			return;
		}

		// If the clip was loaded correctly, play the function above
		PlayAudio (clip, volume, pitch, loop);
	}

	public void StopAudio(AudioClip clip){
		// Get the name from the clip, and then play the StopFunction which needs a name
		StopAudio (clip.name);
	}

	public void StopAudio (string clipName){
		// Loop through all the audioSources we have
		foreach (AudioSource audioSource in audioSources) {
			// Do the clip names match, and is the clip playing?
			if(audioSource.clip.name == clipName && audioSource.isPlaying)
				// Stop the audioSource
				audioSource.Stop();
		}
	}

	private AudioSource GetAudioSource()
	{
		// Loop through all the audioSources we have
		foreach (AudioSource audioSource in audioSources) {
			// If the audioSource isn't playing, we can use it
			if(!audioSource.isPlaying)
				return audioSource;
		}

		// This happens in case there wasn't a AudioSource left
		// We create a new AudioSource and add this to the list
		audioSources.Add (gameObject.AddComponent<AudioSource>());
		// We then return the newly created AudioSource, by getting the last source from the list
		return audioSources[audioSources.Count - 1];
	}
}

﻿using UnityEngine;
using System.Xml.Serialization;
using System.IO;

public class XMLManager {

	public static void XMLWrite<T>(T obj, string fileName, string  pathFromResources) {
		XmlSerializer writer = new XmlSerializer (obj.GetType());
		StreamWriter file = new StreamWriter (Application.dataPath + "/Resources/" + pathFromResources + "/" + fileName + ".xml");
		writer.Serialize (file, obj);
		file.Close ();

		Debug.Log ("XML succesfully saved to: " + Application.dataPath + "/Resources/" + pathFromResources + "/" + fileName + ".xml");
	}

	public static T XMLReadFromResources<T>(string fileName, string pathFromResources) {
		XmlSerializer reader = new XmlSerializer (typeof(T));
		//TextAsset xmlDoc = (TextAsset)Resources.Load(pathFromResources + "/" + fileName, typeof(TextAsset));
		TextAsset xmlDoc = Resources.Load<TextAsset> (pathFromResources + "/" + fileName);
		StringReader file = new StringReader (xmlDoc.text);
		T result = (T)reader.Deserialize (file);
		file.Close ();

		return result;
	}
}
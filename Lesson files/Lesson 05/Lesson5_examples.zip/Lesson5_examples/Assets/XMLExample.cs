﻿using UnityEngine;
using System.Collections.Generic;

public class XMLExample : MonoBehaviour {

	public enum lang
	{
		NL_XML,
		ENG_XML
	}

	public string fileName = "NL_XML";
	public int index = 0;
	public string selectedText = "";

	private List<TextItem> myTextLibrary;

	private void Start() {
//		myTextLibrary = new List<TextItem> () {
//			new TextItem(0, "Hallo mjensen"),
//			new TextItem(1, "Hallo apen"),
//			new TextItem(2, "Hallo nasi's")
//		};
//
//		XMLManager.XMLWrite<List<TextItem>>(myTextLibrary, "NL_XML", "XML");

		myTextLibrary = XMLManager.XMLReadFromResources<List<TextItem>> (fileName, "XML");
	}

	private void Update() {
		selectedText = GetTextByIndex(index);
	}

	private string GetTextByIndex(int index) {
		foreach (TextItem t in myTextLibrary) {
			if (t.index == index) {
				return t.text;
			}
		}

		return ":(";
	}

}

public class TextItem {
	public int index;
	public string text;
	
	public TextItem() {}
	public TextItem(int index, string text) {
		this.index = index;
		this.text = text;
	}
}
﻿using UnityEngine;
using System.Collections;

public class Entity : MonoBehaviour {

    protected SpriteRenderer renderer;

    protected int hp = 5;
    protected int attack = 5;
    protected int speed = 3;

	protected bool isDeath;

    protected virtual void Start()
    {
        renderer = GetComponent<SpriteRenderer>();
    }

    public virtual void OnClick(int damage)
    {
		if (isDeath)
			return;

        hp -= damage;

		if (hp <= 0)
			OnDeath ();

        StartCoroutine(CallHit());
    }

    private IEnumerator CallHit()
    {
        float timer = 0f;
        float totalTime = 0.5f;

        while(true)
        {
            timer += Time.deltaTime;
            renderer.color = Color.Lerp(Color.red, Color.white, timer / totalTime);

            if (timer / totalTime >= 1f) break;

            yield return null;
        }
    }

	protected virtual void OnDeath()
	{
		OnDeath ("Uuuurgh");
	}

	protected void OnDeath(string text)
	{
		isDeath = true;
		renderer.enabled = false;
		Debug.Log (text);
	}
}

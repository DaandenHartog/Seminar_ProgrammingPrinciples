﻿using UnityEngine;
using System.Collections;

public class Knight : Entity {

	public string name;
	protected int defence = 1;

	public override void OnClick (int damage)
	{		
		base.OnClick (damage - defence);
	}

	protected override void OnDeath ()
	{
		OnDeath ("Oh neen! Ik, ridder " + name + " sterf in deze vervloekte landen!");
	}

	private void Update()
	{
		Vector2 input = Vector2.zero;

		if (Input.GetKey (KeyCode.A))
			input += Vector2.left;
		if (Input.GetKey (KeyCode.D))
			input = new Vector2 (1, input.y);
		if (Input.GetKey (KeyCode.W))
			input = new Vector2 (input.x, 1);
		if (Input.GetKey (KeyCode.S))
			input = new Vector2 (input.x, -1);

		if (input != Vector2.zero)
			transform.Translate (input * speed * Time.deltaTime);
	}

}

﻿using UnityEngine;
using System.Collections;

public class Cursor : MonoBehaviour {

    public int damage = 1;
    	
	private void Update () {

	    if(Input.GetMouseButtonDown(0))
        {
            RaycastHit2D ray = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);

            if (ray.collider == null) return;

            if (ray.collider.tag == "entity")
                ray.collider.GetComponent<Entity>().OnClick(damage);
        }

	}
}

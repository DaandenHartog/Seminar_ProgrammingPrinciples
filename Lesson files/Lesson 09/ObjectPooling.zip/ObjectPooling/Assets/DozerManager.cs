﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DozerManager : MonoBehaviour {

	private List<GameObject> coins = new List<GameObject>();

	public GameObject coinPrefab;

	public GameObject GetCoin()
	{
		if(coins.Count == 0)
			coins.Add(GameObject.Instantiate(coinPrefab) as GameObject);

		GameObject coin = coins [0];
		coin.SetActive (true);

		coins.Remove (coin);

		return coin;
	}

	public void RemoveCoin(GameObject coin)
	{
		coins.Add (coin);
		coin.SetActive (false);
	}

}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DozerGame : MonoBehaviour {

	private List<GameObject> coins = new List<GameObject>();
	private DozerManager dozer;

	public GameObject coinPrefab;

	// Use this for initialization
	private void Start () {
		dozer = GetComponent<DozerManager> ();

		for (int i = 0; i < 4; i++) {
			AddCoin();
		}
	}

	private void AddCoin()
	{ 
		GameObject coin = dozer.GetCoin ();

		coins.Add (coin);
		coin.transform.position = new Vector3 (Random.Range (0, 5), coinPrefab.transform.position.y, coinPrefab.transform.position.z);
	}
	
	// Update is called once per frame
	private void Update () {

		if (Input.GetKeyDown (KeyCode.Space))
			AddCoin ();


		for (int i = 0; i < coins.Count; i++) {

			GameObject coin = coins[i];

			coin.transform.Translate(Vector3.down * 2f * Time.deltaTime);

			if(coin.transform.position.y < -5)
			{
				coins.Remove(coin);
				dozer.RemoveCoin(coin);
				i--;
			}
		}
	}
}

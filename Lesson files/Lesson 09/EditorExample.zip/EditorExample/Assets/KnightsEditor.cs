﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(Knight))]
public class KnightsEditor : Editor {

	SerializedProperty hpProp;
	SerializedProperty armorProp;
	SerializedProperty gunProp;

	void OnEnable() {
		hpProp = serializedObject.FindProperty("healthPoints");
		armorProp = serializedObject.FindProperty("armor");
	}

	public override void OnInspectorGUI() {
		Knight mp = (Knight)target;

		mp.healthPoints = EditorGUILayout.IntSlider("HP", mp.healthPoints, 0, 100);
		ProgressBar(mp.healthPoints / 100.0f, "HP");

		mp.armor = EditorGUILayout.IntSlider("Armor", mp.armor, 0, 100);
		ProgressBar(mp.armor / 100.0f, "Armor");
	}

	// Custom GUILayout progress bar.
	void ProgressBar(float value, string label) {
		Rect rect = GUILayoutUtility.GetRect(18, 18, "TextField");
		GUI.color = value > .5f ? Color.green : Color.red;
		EditorGUI.ProgressBar(rect, value, label);
		GUI.color = Color.white;
		EditorGUILayout.Space();
	}
}
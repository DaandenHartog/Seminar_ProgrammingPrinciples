﻿using UnityEngine;

public class Knight : MonoBehaviour {

	public int healthPoints;
	public int armor;

	private Orc orc;
	private string text = "Hallo mjensen";

	private void Start() {
		Debug.Log("Hallo ik ben een knight");

		orc = GameObject.Find("orc").GetComponent<Orc>();
		if (orc == null) {
			return;
		}

		Debug.Log("De distance tussen mij en de orc is: " + CheckDistance());

		text.Display();

		Vector3 vec = new Vector3(100, 50, 100);
		vec = vec.AddNumberToVector3(2, 2, 2);
		vec.Display();
	}

	private float CheckDistance() {
		float distance = Vector2.Distance(transform.position, orc.transform.position);
		return distance;
	}
}

public static class Extensions {

	public static void Display(this string str) {
		Debug.Log(str);
	}

	public static void Display(this Vector3 vec) {
		Debug.Log(vec);
	}

	public static Vector3 AddNumberToVector3(this Vector3 vec, float addToX, float addToY, float addToZ) {
		return new Vector3(vec.x + addToX, vec.y + addToY, vec.z + addToZ);
	}

}